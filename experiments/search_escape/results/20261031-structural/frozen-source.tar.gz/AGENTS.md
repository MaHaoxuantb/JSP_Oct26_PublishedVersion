# Solver maintenance

- Do not change fan settings or force fan speeds for experiments. Leave the user's existing cooling controls unchanged.
- `JaneStreetPuzzle_Oct26/SoftwareVersion.swift` is the software release authority. Increment `SoftwareVersion.current` whenever changing core code executed by workers or the coordinator, including search, scoring, validation, wire messages, persistence, credentials, management, or the dashboard. Use one new monotonically increasing integer for each coherent release/change set; never reuse a released number. Documentation-only changes do not require a bump.
- Software version is separate from `WireMessage.version`. Bump the wire protocol version as well for incompatible framing/schema changes. Keep saved-state decoding compatible when adding fields.
- Review `minimumPeerVersion` defaults after a bump: it defaults to the current software version. Older/unversioned workers are rejected before reports or assignments are processed. Setting it to 0 explicitly allows legacy peers for a transition; future versions remain rejected. Test both strict and transitional behavior.
- Default coordinator startup reuses configured TLS certificate, private key, and join token. Never silently regenerate missing, expired, or mismatched credentials. Initialization and rotation must be explicit. Never log credentials or commit private keys/tokens.
- Preserve run IDs, checkpoints, active assignments, and durable state during updates. Never replace live SQLite files or synchronize them through iCloud.
- Build and test new work in an isolated scratch directory; do not overwrite an installed worker executable as a side effect of testing. Set `PUZZLE_TEST_EXECUTABLE` to the isolated product when running process recovery tests. Deployment requires the user's authorization for that release. Respect an explicit “don't deploy yet.”
- When authorized to deploy, inspect the existing launch mechanism and reuse its tmux session where applicable. Do not create duplicate workers. Local macOS Documents permission issues are managed by the user; do not repeatedly request access.

# Experiment publication identity

- Follow [EXPERIMENT-NAMING.md](EXPERIMENT-NAMING.md) for current and future experiment artifacts.
- Use the exact notice `©2026 ThomasB`, author `ThomasB`, and names in the form `JSP-Oct26-<ExperimentName>`.
